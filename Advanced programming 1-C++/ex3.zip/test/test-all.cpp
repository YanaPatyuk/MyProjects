/*
# Ori Cohen
# ID: 207375783
# Yana Patyuk
# ID:317106755
 */

#include "gtest/gtest.h"

GTEST_API_ int main(int argc, char **argv) {
 testing::InitGoogleTest(&argc, argv);
 return RUN_ALL_TESTS();
}


