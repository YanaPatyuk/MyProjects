/*
 * main.cpp
 * Author: Yana Patyuk
 * ID: 317106755
 */
#include "Board.h"

int main() {
	Board b(8,8);
	b.print();
//	b.~Board();
}
