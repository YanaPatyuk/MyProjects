/*
 * Board.h
 *      Author: Yana Patyuk
 *      ID:317106755
 */
#ifndef BOARD_H_
#define BOARD_H_
#include <iostream>
#include <string>

using namespace std;
class Board {
	public:
		/************************************************************************
		 * function name: constructor of board object*
		 * The input:no input.
		 * The output:no output*
		 *The Function operation: set players symbol and create an empty board with only 4 players*
		 *************************************************************************/
		Board(int l = 8, int w = 8);
		/************************************************************************
		* function name: print*
		* The input:no input.
		* The output:no output*
		*The Function operation: print the board*
		*************************************************************************/
		void print();
		~Board();
	private:
		char playerX;
		char playerO;
		char empty;
		char **board;
		int size;
};

#endif /* BOARD_H_ */
