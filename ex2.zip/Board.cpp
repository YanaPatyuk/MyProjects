/*
 * Board.cpp
 * Author: Yana Patyuk
 * ID: 317106755
 */
#include "Board.h"
using namespace std;

Board::Board(int l,  int w ): playerX('X'), playerO('O'), empty(' ') {
	size = l;
board = new char*[size];
for (int i = 0; i < size; i++) {
	board[i] = new char[size];
}

//set empty space in each square in the board.
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
					board[i][j] = empty;
			}
		}
	//set the first places of players.
/*	board[size/2][size/2] = playerO;
	board[size/2-1][size/2 -1] = playerO;
	board[size/2][size/2 - 1] = playerX;
	board[size/2 - 1][size/2] = playerX;*/
}


void Board::print() {

cout << " |";
		for (int i = 1; i <= size; i++) {
		cout << " " << i << " |";
	}
	cout << endl;
	cout << "---------------------------------" << endl;
	for (int i = 0; i < size; i++) {
		cout << "" << i + 1 << "|";
		for (int j = 0; j < size; j++) {
			cout << " " << board[i][j] << " |";
		}
		cout << endl;
		cout << "----------------------------------" << endl;
		}
	}

Board::~Board() {
		for (int i = 0; i < size; i++) {
			delete[] board[i];
		}
		delete[] board;
	}


