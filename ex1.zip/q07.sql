SELECT COUNT(name)
FROM (SELECT name
      FROM (SELECT name, (replacement_cost - rental_rate) as difference
      	    FROM category, (SELECT category_id, rental_rate, replacement_cost
		      	    FROM film_category, (SELECT film_id, rental_rate, replacement_cost
					     	 FROM film) AS film_reduced_table
		      	    WHERE film_category.film_id=film_reduced_table.film_id) AS category_id_reduced_table
            WHERE category.category_id=category_id_reduced_table.category_id) as category_reduced_table
      GROUP BY name
      HAVING AVG(difference) > 17) as average_reduced_table;
