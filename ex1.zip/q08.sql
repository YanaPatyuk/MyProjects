SELECT (CONCAT(t1.first_name, ' ', t1.last_name)) AS full_name
FROM (SELECT actor_id, first_name, last_name
      FROM actor
      WHERE NOT EXISTS (SELECT actor_id
			FROM actor AS b
			WHERE actor.actor_id<>b.actor_id AND actor.first_name=b.first_name)) AS t1,
     (SELECT actor_id, last_name
      FROM actor
      GROUP BY last_name
      HAVING count(last_name)>=4) AS t2
WHERE t1.last_name=t2.last_name
ORDER BY full_name;
