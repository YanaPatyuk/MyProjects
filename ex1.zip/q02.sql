SELECT DISTINCT last_name FROM actor WHERE first_name='SUSAN' ORDER BY last_name ASC;
