SELECT DISTINCT country
FROM (SELECT customer_id, country
      FROM country, (SELECT customer_id, city, country_id
		     FROM city, (SELECT customer_id, city_id
			   	 FROM customer, address
			   	 WHERE customer.address_id=address.address_id) AS address_reduced_table
	       	     WHERE city.city_id=address_reduced_table.city_id) AS city_reduced_table
      WHERE city_reduced_table.country_id=country.country_id) as country_reduced_table
GROUP BY country
HAVING COUNT(country) > 10 and COUNT(country) < 20;
