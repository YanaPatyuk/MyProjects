SELECT COUNT(customer_id)
FROM (SELECT customer_id, city
      FROM city, (SELECT customer_id, city_id
		  FROM customer, address
		  WHERE customer.address_id=address.address_id) AS address_reduced_table
      WHERE city.city_id=address_reduced_table.city_id and city.city='Aurora') AS city_reduced_table;
