SELECT first_name, last_name
FROM actor WHERE first_name=ANY(SELECT first_name
				FROM actor
				WHERE actor_id=8)
		 AND
		 actor_id<>8
UNION ALL
SELECT first_name, last_name
FROM customer
WHERE first_name=ANY(SELECT first_name
		     FROM actor
		     WHERE actor_id=8);
