SELECT name FROM category ORDER BY name ASC;
