SELECT full_name, COUNT(full_name) AS NC_17_Movies
FROM (SELECT CONCAT(first_name, ' ', last_name) AS full_name, rating
      FROM (SELECT first_name, last_name, rating
	    FROM (SELECT first_name, last_name, film_id
	     	  FROM film_actor
		  INNER JOIN actor ON film_actor.actor_id=actor.actor_id) AS actor_film_id_table
	    INNER JOIN film ON actor_film_id_table.film_id=film.film_id) AS actor_film_table
      WHERE rating='NC-17') AS actor_film_nc_17_table
GROUP BY full_name
HAVING count(full_name)>10;
